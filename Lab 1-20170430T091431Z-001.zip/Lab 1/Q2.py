"Q 2"



x = int(input ("Enter a month"))
z= x

if x<=3:
    print ("This is Winter Season!")
elif x<=6:
    print ("This is Summer Season")
elif x<=9:
    print ("This is Summer seasoN")
else:
    print ("This is Autum Season")