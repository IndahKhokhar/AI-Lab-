"Even Odd"


x = input ('Enter a number')
z = int (x)

if (z%2 == 0):
        print ("The number is even")
else:
    print ("The number is odd")