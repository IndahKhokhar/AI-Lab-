"ADDING"


x= int (input ('Enter value of x?'))
y = int (input ('Enter value of y?'))
z = x + y

print (z)