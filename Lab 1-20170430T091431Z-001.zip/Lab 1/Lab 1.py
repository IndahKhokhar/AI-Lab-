"Q 1"


print ("CV");
print ("Name: Khokhar \t")
print ("GPA: 3.73 \t")
print ("Degree: B(Cs) \t")
print ("Institude: Iqra University")
