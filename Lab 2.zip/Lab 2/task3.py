def khokhar ():

    l = []
    for z in range(1,21):
        l.append (z*z)

    print(l)

khokhar()



