import numpy as np

a=np.arange(15)
a = a.reshape(3,5)
print(a.shape)